javascript:document.body.onmousedown = function() { alert("TROLLED")}
