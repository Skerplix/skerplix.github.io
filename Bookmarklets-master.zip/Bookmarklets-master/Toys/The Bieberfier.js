//Changes all images on the page to Justin Beiber

javascript:(function(){Array.prototype.slice.call(document.querySelectorAll('img')).map(function(el){el.src = '//codebox.org.uk/graphics/bieber.jpg';});}())
