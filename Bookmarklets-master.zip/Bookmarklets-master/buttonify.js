//show allows you to make evrything into buttons

javascript:x=document.body; t="button"; x.innerHTML="<"+t+">" + x.innerHTML + "</"+t+">"; void(0);
