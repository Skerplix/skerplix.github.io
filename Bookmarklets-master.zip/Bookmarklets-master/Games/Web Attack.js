javascript:var s = document.createElement('script');s.type='text/javascript';document.body.appendChild(s);s.src='http://grsmto.com/lab/webattack/webattack.min.js';void(0);
