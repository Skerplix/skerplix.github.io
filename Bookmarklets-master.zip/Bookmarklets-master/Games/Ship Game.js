//Puts a flying ship on the page (you can navigate around and shoot using "space")

javascript:var s = document.createElement('script');s.type='text/javascript';document.body.appendChild(s);s.src='http://erkie.github.com/asteroids.min.js';void(0);
