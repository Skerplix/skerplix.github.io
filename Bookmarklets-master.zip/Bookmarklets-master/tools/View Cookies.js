//Allows you to see cookies

javascript:alert('Cookies stored by this host or domain:\n\n' + document.cookie.replace(/; /g,'\n'));
