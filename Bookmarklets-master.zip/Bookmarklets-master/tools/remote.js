//show creates a tab with setting and commands 

javascript:window.name = 'receiver'; window.open('http://www.squarefree.com/bookmarklets/remotePageLinks.html','','resizable=yes,width=223,height=337,left=508,top=122'); void 0
