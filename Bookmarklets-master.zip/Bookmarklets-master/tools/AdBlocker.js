//Basically an ad-blocker

javascript:void(F=document.getElementsByTagName('iframe'));for(f=0;f<F.length;f++)void(F[f].src='about:');void(F=document.getElementsByTagName('img'));for(f=0;f<F.length;f++)if(F[f].width=='468')void(F[f].src='about:');
