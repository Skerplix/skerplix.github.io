//Allows you to see the build of the page when you click on a element

javascript:function loadScript(scriptURL) %7B var scriptElem = document.createElement('SCRIPT'); scriptElem.setAttribute('language', 'JavaScript'); scriptElem.setAttribute('src', scriptURL); document.body.appendChild(scriptElem);%7DloadScript('http://westciv.com/xray/thexray.js');
