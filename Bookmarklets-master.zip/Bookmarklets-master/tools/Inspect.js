//Allows you to see many html features on the webiste. Basically inspect element but you can't edit anything

javascript:s=document.body.appendChild(document.createElement('script'));s.id='fs';s.language='javascript';void(s.src='http://slayeroffice.com/tools/suite/suite.js');
