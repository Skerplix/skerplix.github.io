//Asks for a word and then defines it

javascript:var word = prompt("What word do you want to define?"); window.open("http://www.dictionary.com/browse/" + word +"?s=t");
