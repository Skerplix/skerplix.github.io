//Allows you to edit the text of a page (change values to false and click again to disable)

javascript:document.body.contentEditable = 'true'; document.designMode='on'; void 0
